<?php 
	//database connection
	require_once 'config.php';
	$db = mysqli_connect(DB_HOST,DB_USER,DB_PASS,DB_NAME) or die("database is not connected");


//function for showing pages
function showPage($page,$data=""){
	include("assets/pages/$page.php");
}


//function for show error
function showError($field){
	if (isset($_SESSION['error'])) {
			// code...
		$error =$_SESSION['error'];
			if (isset($error['field']) && $field==$error['field']) {
				// code...
				?>
				<div class="alert alert-danger my-2" role="alert">
  				<?=$error['msg']?>
				</div>
				<?php
			}
		}
	}


//function for show prevformdata
	function showFormData($field){
		if (isset($_SESSION['formdata'])) {
			// code...
			$formdata =$_SESSION['formdata'];
			return $formdata[$field];
	}
}


//for chaking dublicate email
function isEmailRegistered($email){
	global $db;
	$query="SELECT count(*) as row FROM user WHERE email='$email'";
	$run=mysqli_query($db,$query);
	$return_data = mysqli_fetch_assoc($run);
	return $return_data['row'];
}


//for chaking dublicate username
function isUsernameRegistered($username){
	global $db;
	$query="SELECT count(*) as row FROM user WHERE username='$username'";
	$run=mysqli_query($db,$query);
	$return_data = mysqli_fetch_assoc($run);
	return $return_data['row'];
}


//for validating the signup form
	function validateSignupForm($from_data){
		$response=array();
		$response['status']=true;

		if (!$from_data['password']) {
			// code...
			$response['msg']="password is not given";
			$response['status']=false;
			$response['field']='password';
		}
		if (!$from_data['email']) {
			// code...
			$response['msg']="email is not given";
			$response['status']=false;
			$response['field']='email';
		}
		if (!$from_data['username']) {
			// code...
			$response['msg']="username is not given";
			$response['status']=false;
			$response['field']='username';
		}

		if (isEmailRegistered($from_data['email'])) {
			// code...
			$response['msg']="email id is already registered";
			$response['status']=false;
			$response['field']='email';
		}
		if (isUsernameRegistered($from_data['username'])) {
			// code...
			$response['msg']="username is already registered";
			$response['status']=false;
			$response['field']='username';
		}

		return $response;
	}
//for validating the login form
	function validateLoginForm($from_data){
		$response=array();
		$response['status']=true;
		$blank=false;

		if (!$from_data['password']) {
			// code...
			$response['msg']="password is not given";
			$response['status']=false;
			$response['field']='password';
			$blank=true;
		}
		if (!$from_data['username_email']) {
			// code...
			$response['msg']="username/email is not given";
			$response['status']=false;
			$response['field']='username_email';
			$blank=true;
		}
		if (!$blank && !checkUser($from_data)['status']) {
			// code...
			$response['msg']="Something is incorrect, we can't find you";
			$response['status']=false;
			$response['field']='checkuser';
		}else{
			$response['user']=checkUser($from_data)['user'];
		}

		return $response;
	}


//for checking the user
function checkUser($login_data){
	global $db;
	$username_email = $login_data['username_email'];
	$password=md5($login_data['password']);

	$query = "SELECT * FROM user WHERE (email='$username_email' || username='$username_email') && password='$password'";
	$run = mysqli_query($db,$query);
	$data['user'] = mysqli_fetch_assoc($run)??array();
	if(count($data['user'])>0){
		$data['status']=true;
	}else{
		$data['status']=false;
	}
	return $data;
}

//for creating new user
	function createUser($data){
		global $db;
		$username = mysqli_real_escape_string($db,$data['username']);
		$email = mysqli_real_escape_string($db,$data['email']);
		$password = mysqli_real_escape_string($db,$data['password']);
		$password = md5($password);

		$query = "INSERT INTO user(username,email,password)";
		$query.="VALUES ('$username','$email','$password')";
		return mysqli_query($db,$query);
	}

 ?>